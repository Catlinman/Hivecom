
[HIVECOM TEAMSPEAK 3 SKIN BY CATLINMAN]
		[http://hivecom.net]

---------------------------------------

[ENGLISH]
-> INSTALLATION <-
To install the skin simply extract the contents to your root client Teamspeak 3 directory (default for the 32-bit version is "C:\Program Files (x86)\TeamSpeak 3 Client\").
From there on all you have to do is to select the Hivecom skin and icon pack from the design menu. To get there simply navigate to the options menu and select the design
submenu from the list on the left hand side.

-> CONTACT <-
For questions and suggestions give Catlinman a shout.

Twitter: @Catlinman_
Website: http://catlinman.com
Email: dev.catlinman@gmail.com

---------------------------------------

[DEUTSCH]
-> INSTALLATION <-
Um den Skin in Teamspeak 3 zu verwenden m�ssen vorerst alle Ordner und ihr Inhalt in den installations
Ordner (standardm��ig f�r die 32-bit Version ist "C:\Program Files (x86)\TeamSpeak 3 Client\") von Teamspeak extrahiert werden. Von dort aus kann man den Skin im Design
raster ausw�hlen. Dieses findet man im Einstellungs-Fenster von Teamspeak welches �ber die Leiste am oberen Bildschirmrand ge�ffnet werden kann.

-> KONTAKT <-
F�r weitere Fragen und Vorschl�ge k�nnt ihr euch an Catlinman wenden.

Twitter: @Catlinman_
Website: http://catlinman.com
Email: dev.catlinman@gmail.com